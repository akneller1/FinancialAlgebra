# Phase 2 handoff: pictures and art for Grades 1–5

From Claude (content and design) to ChatGPT (site implementation), 2026-11-15.
This builds on the Phase 1 package (`kid-friendly-phase1-handoff.zip`). Do Phase 1 first.

## What is in this package

| Path | What it is |
| --- | --- |
| `patches/math1/*.story-pictures.json` | Story pictures for 412 Grade 1 questions: one edit per question that sets `diagram` (it has none today) and appends a line to `sourceNotes`. |
| `assets/question-banks/assets/math1/<unit>/<id>.png` | The 412 PNGs, made the same way as the existing Grade 1 diagrams (`rsvg-convert -z 1.25`, 96-color palette). |
| `apply-story-pictures.mjs` | Applies the patches and copies the PNGs into a FinancialAlgebra checkout. It checks everything first and stops without changing anything if a question is missing, already has a diagram, or a PNG would be overwritten. |
| `math1-pictures-added.csv` | Every question that got a picture: id, unit, level, format, picture type, size, prompt, answer, alt text. |
| `art/objects/*.svg` | The countable-object library: 37 original objects (apple, ball, balloon, bead, bee, bird, block, book, box, bug, button, car, carrot, cat, cookie, crayon, cube, cup, dog, duck, egg, fish, flower, frog, hat, kite, leaf, marble, orange, pen, pencil, rock, shell, star, straw, strawberry, toy). 48 × 48, site ink outline. |
| `art/mascots/*.svg` | One original mascot per grade, for the title band: Dot (Grade 1, a counting counter), Cubie (Grade 2, a connecting cube), Hexie (Grade 3, a pattern-block hexagon), Zoom (Grade 4, a rocket), Bit (Grade 5, a robot). |
| `art/unit-badges/grade1/<unit-id>.svg` | 12 Grade 1 unit badges, one per unit id, for the left slot of the title band. |
| `elementary-print.css` | Phase 1 stylesheet with two Phase 2 changes (see "Print layout changes"). Replaces the Phase 1 file. |
| `samples/grade1-word-problems-with-pictures.pdf` | Target page: Phase 1 layout plus unit badge, mascot and story pictures. |
| `previews/*.png` | Contact sheets: object library, mascots and badges, one example of each picture type. |
| `scripts/` | Source for everything above (parser, drawing, independent checker, build). Re-run with `build_pictures.py <FinancialAlgebra> math1 <built _site> <out>`. |

## 1. Story pictures (Grade 1)

**Where they go.** The Grade 1 question banks live in `akneller1/FinancialAlgebra` at the commit pinned in Classroom's `.github/workflows/deploy-site.yml` (Grade 1 step: `87550721…`).

1. In a FinancialAlgebra checkout at that commit (or newer): `node apply-story-pictures.mjs <path to FinancialAlgebra> <path to this package>`
   It should print `Story pictures applied: 412 questions in 6 bank files.`
2. Commit, then move the Grade 1 `ref:` in Classroom's `deploy-site.yml` to the new commit.

Nothing in Classroom's code needs to change: the existing Grade 1 assembler copies `question-banks/assets/math1/…`, and every player, generator and printable already shows `diagram`.

**Tested here.** I applied the patches to a copy of FinancialAlgebra at the pinned commit and rebuilt the site with the deploy workflow's own steps and order. These all passed:
- `test-grade1-release.cjs`: 4,230 practice questions, 282 checks.
- `test-grade1-projects.cjs`.
- `test-content-release.cjs`: diagram assets across 36 banks.
- `test-elementary-generators.cjs`.

The pictures appear in the Worksheet Generator and in the Grade 1 game players.

**Coverage.** Grade 1 story problems with a picture rise from 17% to 64% (137 → 527 of 823, same measure as the audit). By unit:

| Unit | Pictures added |
| --- | --- |
| word-problems-20 | 273 |
| add-subtract-10 | 59 |
| add-subtract-20 | 31 |
| equal-sign | 24 |
| count-120 | 21 |
| add-subtract-100 | 4 |

That is 133 Support (`cp2`), 140 On Level (`cp1`) and 139 Challenge (`honors`) questions; 215 short-answer and 197 multiple-choice. Stories with groups over 20 objects, tens-and-ones bundles, tallies and "Which could be true?" questions were left alone.

**Picture types** (one example each in `previews/picture-types.png`). All follow standard Grade 1 models:

| Type | Count | Story | Picture |
| --- | --- | --- | --- |
| add | 75 | has 5, gets 3 more | two trays: 5 and 3 |
| take | 71 | has 10, gives away 3 | 10 objects, last 3 crossed out |
| fill | 51 | has 7, wants 10 / gets some, now has 10 | 7 objects + 3 dashed empty spots |
| compare | 47 | Finn has 9, Liz has 3 | two labeled rows, lined up |
| colors_rest | 40 | 7 in all, 3 blue, the rest green | 3 blue + 4 uncolored (to color in) |
| mixed | 32 | 9 in one box, 2 in another / pets | one tray per group |
| hidden | 29 | 9 in all, some under a cup, see 6 | 6 objects + cup with "?" and "9 in all" |
| compare_diff | 26 | Zoe has 2, Ben has 5 more | Ben's row: Zoe's 2 + 5 extra in yellow (or empty spots for "fewer") |
| group | 19 | there were 8, some flew away, now 7 | 8 objects (the child crosses out) |
| add_start | 13 | had some, got 7 more, now 13 | bag with "?" + 7 objects, "13 now" |
| colors | 9 | 4 blue and 6 green apples | colored groups |

**Teacher choice.** For *fill*, *compare_diff* and *colors_rest* (117 questions), counting the picture leads straight to the answer, the way a ten frame does. That is the point for Support and On Level. If Mr. K would rather Challenge students draw their own models, skip the edits whose `id` contains `-honors-` and whose type (CSV `kind`) is one of those three.

**Checks.** Every picture passed an independent checker (`scripts/verify.py`, which shares no code with the parser or drawing). It counts the objects, cross-outs and empty spots actually drawn, compares them with the numbers in the story, and confirms that the bank's own answer matches the number the story asks for. To prove it catches errors, I fed it 150 deliberately miscounted pictures. It caught every one that changed the drawing (142 of 142, plus 16 of 16 on color rows); the other 8 mutations left the drawing unchanged. Every picture has alt text (CSV column `alt`).

## 2. Art in the page templates

- **Title band** (Phase 1 `.el-band`): left slot (`.el-mascot`, 0.75 in) shows the unit badge, `art/unit-badges/grade1/<unit-id>.svg`, with the unit id taken from the `grade1-<unit-id>` route. Right side: the grade mascot at 0.8 in, `art/mascots/grade1-dot.svg` (`grade2-cubie`, `grade3-hexie`, `grade4-zoom`, `grade5-bit`). Grades 2–5 use the mascot in both slots until their unit badges are made.
- **Also use the mascot** on: cheat sheets (rename to "My Math Helper" for Grades 1–2), flashcard backs, the Understanding Check start and finish screens, and the game Play screen (Phase 4).
- All art is original, uses the site palette (`#14173a` ink, `#ff8a1f`, `#3547f5`, `#22c08a`, `#7448ff`, `#ffd23f`), and has a `<title>` for screen readers.

## 3. Print layout changes (in `elementary-print.css`)

- Grades 1–2 picture height cap: 1.25 in → 2.1 in. With the old cap, a 3-row picture shrank its objects to about 0.2 in. They now print at about 0.4–0.5 in.
- New `.el-figrow`: when a short-answer question has a picture, put the picture and the Answer box side by side, and drop the separate work area, because the picture is the work space. Grade 1 pages with pictures hold 2–3 questions. See the sample PDF.

## Next from Claude (Phase 3)

Story pictures for Grade 2, unit badges for Grades 2–5, and the redesigned activities (in-room mazes, color swatches, Roll & Cover, Cut & Paste, Number Bonds, Spin & Solve) plus "Show What You Know" item picks.
