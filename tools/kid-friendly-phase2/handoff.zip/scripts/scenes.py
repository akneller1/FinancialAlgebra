"""Draw a story spec (from stories.py) as an SVG scene, plus alt text.

Layout rules for young counters: groups are laid out in rows of 5; separate groups sit in their own rounded tray;
crossed-out objects keep their place; empty dashed slots show "how many more"; a cup or box with "?" hides objects.
"""
from objects import draw, cross, outline, INK, TINTS

P = 50          # pitch between objects (px)
Z = 44          # object size
FONT = 'font-family="DejaVu Sans, Arial, sans-serif" font-weight="700"'


def svg(w, h, body):
    return f'<svg xmlns="http://www.w3.org/2000/svg" width="{w:.0f}" height="{h:.0f}" viewBox="0 0 {w:.0f} {h:.0f}"><rect width="100%" height="100%" fill="#ffffff"/>{body}</svg>'


def grid(items, x0, y0, per=5, gap5=False):
    """items: list of (kind, name, color). kind: obj | crossed | slot. gap5: extra space after every 5th column.
    Returns svg, width, height."""
    out = ""
    for i, (k, name, col) in enumerate(items):
        r, c = divmod(i, per)
        x, y = x0 + c * P + (c // 5) * (12 if gap5 else 0), y0 + r * P
        if k == "slot": out += outline(x, y, Z)
        else:
            out += draw(name, x, y, Z, col)
            if k == "crossed": out += cross(x, y, Z)
    rows = max(1, -(-len(items) // per))
    cols = min(len(items), per)
    return out, cols * P + ((cols - 1) // 5) * (12 if gap5 else 0), rows * P


def tray(x, y, w, h, fill="#f4f6ff"):
    return f'<rect x="{x:.1f}" y="{y:.1f}" width="{w:.1f}" height="{h:.1f}" rx="14" fill="{fill}" stroke="#c9cfee" stroke-width="2.5"/>'


def groups_side_by_side(groups, label=None):
    """groups: list of item lists. Each group in its own tray, left to right."""
    x, pad, body, H = 12, 12, "", 0
    sizes = []
    for g in groups:
        _, w, h = grid(g, 0, 0)
        sizes.append((w, h)); H = max(H, h)
    for g, (w, h) in zip(groups, sizes):
        body += tray(x, 12, w + 2 * pad, H + 2 * pad)
        body += grid(g, x + pad + 3, 12 + pad + 3)[0]
        x += w + 2 * pad + 18
    return body, x - 6, H + 2 * pad + 24


def bag(x, y, text="?", kind="bag"):
    if kind == "cup":
        shape = (f'<path d="M{x + 6} {y + 92}l12-80h52l12 80z" fill="#2f7fd8" stroke="{INK}" stroke-width="3" stroke-linejoin="round"/>'
                 f'<path d="M{x} {y + 92}h88" stroke="{INK}" stroke-width="4" stroke-linecap="round"/>')
        ty = y + 66
    elif kind == "box":
        shape = (f'<path d="M{x} {y + 30}h88v62H{x}z" fill="#c98a4b" stroke="{INK}" stroke-width="3" stroke-linejoin="round"/>'
                 f'<path d="M{x} {y + 30}l10-18h68l10 18" fill="#e0aa70" stroke="{INK}" stroke-width="3" stroke-linejoin="round"/>')
        ty = y + 74
    else:
        shape = (f'<path d="M{x + 22} {y + 20}c-30 20-26 72 22 72s52-52 22-72z" fill="#e0aa70" stroke="{INK}" stroke-width="3" stroke-linejoin="round"/>'
                 f'<path d="M{x + 26} {y + 20}l-6-12h48l-6 12z" fill="#c98a4b" stroke="{INK}" stroke-width="3" stroke-linejoin="round"/>')
        ty = y + 70
    return shape + f'<text x="{x + 44}" y="{ty}" text-anchor="middle" {FONT} font-size="34" fill="#ffffff" stroke="{INK}" stroke-width="1.5">{text}</text>'


def label(x, y, t, size=20, anchor="start"):
    return f'<text x="{x:.1f}" y="{y:.1f}" text-anchor="{anchor}" {FONT} font-size="{size}" fill="{INK}">{t}</text>'


def items(n, name, kind="obj", col=None):
    return [(kind, name, col)] * n


def render(s):
    k, o = s["kind"], s.get("obj")
    if k == "add":
        body, w, h = groups_side_by_side([items(s["a"], o), items(s["b"], o)])
        return svg(w, h, body)
    if k == "add_start":
        body, w, h = groups_side_by_side([items(s["b"], o)])
        return svg(w + 110, max(h + 30, 130), label(12, 26, f'{s["total"]} now', 20) + f'<g transform="translate(110 30)">{body}</g>' + bag(10, 36))
    if k == "take":
        its = items(s["a"] - s["b"], o) + items(s["b"], o, "crossed")
        body, w, h = groups_side_by_side([its])
        return svg(w, h, body)
    if k == "group":
        body, w, h = groups_side_by_side([items(s["a"], o)])
        return svg(w, h, body)
    if k == "fill":
        its = items(s["a"], o) + items(s["target"] - s["a"], o, "slot")
        body, w, h = groups_side_by_side([its])
        return svg(w, h, body)
    if k in ("colors", "colors_rest"):
        its = []
        for n, col in s["parts"]: its += items(n, o, "obj", col)
        if k == "colors_rest": its += items(s["total"] - sum(n for n, _ in s["parts"]), o, "obj", "white")
        body, w, h = groups_side_by_side([its])
        return svg(w, h, body)
    if k == "hidden":
        top = 30
        body, w, h = groups_side_by_side([items(s["seen"], o)])
        shifted = f'<g transform="translate(0 {top})">{body}</g>'
        return svg(w + 110, max(h + top, 130), label(12, 26, f'{s["total"]} in all', 20) + shifted + bag(w + 8, top + 6, "?", s.get("cover", "cup")))
    if k == "mixed":
        body, w, h = groups_side_by_side([items(n, name) for n, name, _ in s["groups"]])
        return svg(w, h, body)
    if k in ("compare", "compare_diff"):
        rows = []
        if k == "compare":
            used = {c for r in s["rows"] if len(r) == 3 for _, c in r[2]}
            plain = next(c for c in ("purple", "orange", "green", "gray") if c not in used) if used else None
            for r in s["rows"]:
                if len(r) == 3: rows.append((r[0], sum((items(n, o, "obj", c) for n, c in r[2]), [])))
                else: rows.append((r[0], items(r[1], o, "obj", plain)))
        else:
            base, d = s["base"], s["diff"]
            rows.append((s["rows"][0][0], items(base, o)))
            if s["dir"] == "more": rows.append((s["rows"][1][0], items(base, o) + items(d, o, "obj", "yellow" if o != "duck" else "orange")))
            else: rows.append((s["rows"][1][0], items(base - d, o) + items(d, o, "slot")))
        n = max(len(r[1]) for r in rows)
        per = 10 if n > 10 else n
        lines = -(-n // per)
        _, gw, _ = grid([("obj", o, None)] * per, 0, 0, per=per, gap5=True)
        lw = 12 + max(len(r[0]) for r in rows) * 13 + 14
        body, y = "", 10
        for name, its in rows:
            th = lines * P + 10
            body += tray(lw - 8, y, gw + 14, th)
            body += label(12, y + th / 2 + 8, name, 22)
            body += grid(its, lw, y + 8, per=per, gap5=True)[0]
            y += th + 12
        return svg(lw + gw + 18, y, body)
    raise ValueError(k)


IRREG = {"leaf": "leaves", "box": "boxes", "fish": "fish", "strawberry": "strawberries", "cookie": "cookies", "bus": "buses"}
SING = {v: k for k, v in IRREG.items()}


def plural(n, noun):
    one = SING.get(noun, noun[:-1] if noun.endswith("s") and noun not in IRREG else noun)
    return one if n == 1 else IRREG.get(one, one + "s")


def alt(s):
    k, nn = s["kind"], s.get("noun", "")
    p = lambda n: f"{n} {plural(n, nn)}"
    if k == "add": return f"{p(s['a'])} in one group and {p(s['b'])} in another group."
    if k == "add_start": return f"A bag with a question mark and {p(s['b'])}."
    if k == "take": return f"{p(s['a'])}. {s['b']} of them {'is' if s['b'] == 1 else 'are'} crossed out."
    if k == "group": return f"{p(s['a'])}."
    if k == "fill": return f"{p(s['a'])} and {s['target'] - s['a']} empty spaces, {s['target']} spaces in all."
    if k == "colors": return " and ".join(f"{n} {c}" for n, c in s["parts"]) + f" {nn}."
    if k == "colors_rest":
        rest = s["total"] - sum(n for n, _ in s["parts"])
        return f"{p(s['total'])}: " + ", ".join(f"{n} {c}" for n, c in s["parts"]) + f", and {rest} not colored yet."
    if k == "hidden":
        where = "in a box" if s.get("cover") == "box" else "under a cup"
        return f"{p(s['seen'])} you can see and more {where} with a question mark. {s['total']} in all."
    if k == "mixed": return ", ".join(f"{n} {plural(n, name)}" for n, _, name in s["groups"]) + ", each in its own group."
    if k == "compare":
        return " ".join(f"{r[0]}: {r[1]} {plural(r[1], nn)}." for r in s["rows"]) + " The rows line up to compare."
    if k == "compare_diff":
        a, d = s["base"], s["diff"]
        second = (f"{a} {plural(a, nn)} plus {d} more in yellow" if s["dir"] == "more"
                  else f"{a - d} {plural(a - d, nn)} and {d} empty spaces")
        return f"{s['rows'][0][0]}: {p(a)}. {s['rows'][1][0]}: {second}. The rows line up to compare."
    return ""
