"""Build story pictures for one course: PNGs + diagram patch files + a report.

usage: build_pictures.py <FinancialAlgebra checkout> <course e.g. math1> <site _site folder> <out folder>
"""
import json, glob, os, re, sys, io, subprocess, csv, collections
sys.path.insert(0, os.path.dirname(__file__))
from stories import parse
from scenes import render, alt
from verify import check
from PIL import Image

FA, COURSE, SITE, OUT = sys.argv[1:5]
GRADE = COURSE.replace("math", "grade")
DATE = "2026-11-15"
STORY = re.compile(r"\b(has|have|had|sees|saw|buys|gives|gave|takes|there are|there were|gets|got|eats|ate|picks|finds|wants|left|more|fewer)\b", re.I)


def png(svg_text):
    raw = subprocess.run(["rsvg-convert", "-z", "1.25"], input=svg_text.encode(), capture_output=True, check=True).stdout
    im = Image.open(io.BytesIO(raw)).convert("RGB").quantize(colors=96, method=Image.Quantize.MEDIANCUT, dither=Image.Dither.NONE)
    b = io.BytesIO(); im.save(b, "PNG", optimize=True); return b.getvalue(), im.size


site_has_diagram = set()
for f in glob.glob(f"{SITE}/question-banks/{GRADE}/*.json"):
    for q in json.load(open(f))["questions"]:
        if q.get("diagram"): site_has_diagram.add(q["id"])

report, rejected = [], []
by_unit = collections.defaultdict(list)
for f in sorted(glob.glob(f"{FA}/question-banks/{COURSE}/*.json")):
    if "manifest" in f: continue
    unit = os.path.basename(f)[:-5]
    for q in json.load(open(f))["questions"]:
        p = q["prompt"] if isinstance(q["prompt"], str) else ""
        if q.get("diagram") or q["id"] in site_has_diagram or not STORY.search(p): continue
        s = parse(p)
        if not s: continue
        svg_text = render(s)
        probs = check(p, s["kind"], svg_text, q.get("answer"), q["format"])
        if probs:
            rejected.append({"id": q["id"], "unit": unit, "kind": s["kind"], "prompt": p, "answer": q.get("answer"), "problems": "; ".join(probs)})
            continue
        rel = f"question-banks/assets/{COURSE}/{unit}/{q['id']}.png"
        data, size = png(svg_text)
        dest = os.path.join(OUT, "assets", rel)
        if os.path.exists(os.path.join(FA, rel)): raise SystemExit("would overwrite an existing asset: " + rel)
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        open(dest, "wb").write(data)
        os.makedirs(os.path.join(OUT, "svg", COURSE, unit), exist_ok=True)
        open(os.path.join(OUT, "svg", COURSE, unit, q["id"] + ".svg"), "w").write(svg_text)
        a = alt(s)
        by_unit[unit].append({"bank": f"question-banks/{COURSE}/{unit}.json", "id": q["id"], "changes": {
            "diagram": {"from": None, "to": {"type": "image", "spec": {"src": rel, "alt": a}}},
            "sourceNotes": {"append": f" Story picture added {DATE} (Claude, family: story-{s['kind']}); counts re-checked against the story and the answer by an independent checker."}}})
        report.append({"id": q["id"], "unit": unit, "level": q["level"], "format": q["format"], "kind": s["kind"],
                       "width": size[0], "height": size[1], "prompt": p, "answer": q.get("answer"), "alt": a, "png": rel})

os.makedirs(os.path.join(OUT, "patches", COURSE), exist_ok=True)
for unit, edits in by_unit.items():
    json.dump({"description": f"Add story pictures to {len(edits)} {COURSE} {unit} questions ({DATE}). Each edit only sets a diagram where none exists.",
               "edits": edits}, open(os.path.join(OUT, "patches", COURSE, f"{unit}.story-pictures.json"), "w"), indent=1, ensure_ascii=False)
for name, rows in (("pictures-added", report), ("pictures-rejected", rejected)):
    if rows:
        with open(os.path.join(OUT, f"{COURSE}-{name}.csv"), "w", newline="") as fh:
            w = csv.DictWriter(fh, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
print(COURSE, "added", len(report), "rejected", len(rejected), dict(collections.Counter(r["kind"] for r in report)))
print("by unit", {u: len(e) for u, e in by_unit.items()})
for r in rejected[:12]: print("  REJECT", r["id"], r["kind"], "|", r["prompt"].replace("\n", " / ")[:90], "|", r["problems"][:120])
