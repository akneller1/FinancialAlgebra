"""Sample Grade 1 page: Phase 1 layout + Phase 2 art + story pictures (pictures read from this package)."""
import sys, csv, json, html, glob
src = open('/home/claude/phase1/scripts/mockups.py').read()
helpers = src[:src.index('# ---------- Grade 1 worksheet ----------')]
SITE = '/home/claude/akneller1/classroom/_site'; OUT = '/home/claude/phase2/out/samples'
g = {'__name__': 'mk'}; sys.argv = ['x', SITE, OUT]; exec(helpers, g)
g['ICON'] = 'icons/'
patch = {e['id']: e['changes']['diagram']['to'] for f in glob.glob('out/patches/math1/*.json') for e in json.load(open(f))['edits']}
def fig(q):
    d = q.get('diagram')
    if not d: return ''
    return f'<img class="el-fig" src="../assets/{d["spec"]["src"]}" alt="{html.escape(d["spec"]["alt"])}">'
g['fig'] = fig
_q = g['question']
def question(n, q, frac=False, work=False):
    if q.get('diagram') and q['format'] == 'short-answer':
        ans = '<div class="el-answer"><span class="lbl">Answer</span><span class="box"><span class="el-lines"></span></span></div>'
        return (f'<div class="el-q"><span class="el-num">{n}</span><div><p class="el-prompt">{g["txt"](q["prompt"])}</p>'
                f'<div class="el-figrow">{fig(q)}{ans}</div></div></div>')
    return _q(n, q, frac, work)
g['question'] = question
b = g['bank'](1, 'word-problems-20')
for i, d in patch.items():
    if i in b: b[i]['diagram'] = d
added = {r['id']: r['kind'] for r in csv.DictReader(open('out/math1-pictures-added.csv'))}
picks = []
for k in ['compare', 'take', 'colors_rest', 'add_start']:
    for i, kind in added.items():
        q = b.get(i)
        if q and kind == k and q['format'] == 'short-answer' and q['level'] == 'cp2' and '\n' not in q['prompt'] and i not in picks:
            picks.append(i); break
band = ('<div class="el-band"><img class="el-mascot" src="../art/unit-badges/grade1/word-problems-20.svg" alt="">'
        '<div style="flex:1"><div class="el-unit">GRADE 1 · UNIT 5 · PRACTICE</div><h1>Word Problems within 20</h1></div>'
        '<img src="../art/mascots/grade1-dot.svg" alt="Dot" style="width:.8in;height:.8in"></div>')
def page(qs, first, pageno, last):
    head = band + f'<div class="el-name"><img src="icons/name.svg" alt=""><span>My name</span><span class="el-lines"></span></div>' if first else ''
    d = '<div class="el-dir"><img src="icons/write.svg" alt="">Write your answer in the box.</div>'
    foot = f'<div class="el-foot"><span>Mr. K\'s Classroom · {pageno}</span>' + ('<img src="icons/i-did-it.svg" alt="">' if last else '') + '</div>'
    return f'<section class="sheet el-g1">{head}{d}<div class="el-qs">{qs}</div>{foot}</section>'
qh = [g['question'](n + 1, b[i]) for n, i in enumerate(picks)]
doc = g['DOC'].format(t='Grade 1 word problems with pictures', base=g['BASE'],
                      body=page(''.join(qh), True, 'page 1', True))
open(f'{OUT}/grade1-word-problems-with-pictures.html', 'w').write(doc)
print(picks)
