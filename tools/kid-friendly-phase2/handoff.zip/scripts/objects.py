"""Countable-object library for elementary story pictures.

Every object is drawn in a 48 x 48 box with the site's ink outline. `{C}` is the main color, so an object can be
tinted to match a story ("4 red beads and 3 blue beads"). draw(name, x, y, size, color=None) returns an SVG group.
All drawings are original simple shapes.
"""
INK = "#14173a"
S = f'stroke="{INK}" stroke-width="2.4" stroke-linejoin="round" stroke-linecap="round"'
TINTS = {"red": "#e2563b", "blue": "#2f7fd8", "green": "#1aa37a", "yellow": "#f5c400", "orange": "#f08c1a",
         "purple": "#8a5cf0", "pink": "#f27fae", "brown": "#a0673a", "gray": "#9aa0b4", "white": "#ffffff", "black": "#3a3d52"}

# name: (default color, svg body using {C})
OBJ = {
 "apple": ("#e2563b", f'<path d="M24 14c-6-5-17-2-17 11 0 11 9 19 17 16 8 3 17-5 17-16 0-13-11-16-17-11z" fill="{{C}}" {S}/>'
          f'<path d="M24 14c0-4 1-7 4-9" fill="none" {S}/><path d="M26 10c4-5 10-4 12-2-3 4-8 5-12 2z" fill="#1aa37a" {S}/>'
          '<path d="M14 20c-1 3-1 6 0 8" fill="none" stroke="#fff" stroke-width="2.4" stroke-linecap="round" opacity=".7"/>'),
 "ball": ("#2f7fd8", f'<circle cx="24" cy="24" r="18" fill="{{C}}" {S}/><path d="M6.5 22c10 5 25 5 35 0M24 6c-6 10-6 26 0 36" fill="none" stroke="#fff" stroke-width="3"/>'
         f'<circle cx="24" cy="24" r="18" fill="none" {S}/>'),
 "bead": ("#8a5cf0", f'<path d="M5 24h38" stroke="{INK}" stroke-width="2"/><rect x="11" y="12" width="26" height="24" rx="11" fill="{{C}}" {S}/>'
         '<path d="M16 18c2-2 5-3 8-3" fill="none" stroke="#fff" stroke-width="2.4" stroke-linecap="round" opacity=".7"/>'),
 "marble": ("#2f7fd8", f'<circle cx="24" cy="24" r="16" fill="{{C}}" {S}/><path d="M14 28c4 6 14 6 18-2-6 3-12 3-18 2z" fill="#fff" opacity=".55"/>'
           '<circle cx="18" cy="17" r="3.5" fill="#fff" opacity=".85"/>'),
 "bee": ("#f5c400", f'<ellipse cx="18" cy="13" rx="8" ry="6" fill="#e2e6ff" {S}/><ellipse cx="30" cy="12" rx="8" ry="6" fill="#e2e6ff" {S}/>'
        f'<ellipse cx="24" cy="28" rx="16" ry="12" fill="{{C}}" {S}/><path d="M20 17v22M28 17v22" stroke="{INK}" stroke-width="4"/>'
        f'<circle cx="36" cy="25" r="1.8" fill="{INK}"/><path d="M8 28l-5 1" {S}/>'),
 "bird": ("#2f7fd8", f'<path d="M8 30c0-12 8-20 18-20s14 8 14 14c0 10-8 16-18 16-8 0-14-4-14-10z" fill="{{C}}" {S}/>'
         f'<path d="M40 20l7 3-7 3z" fill="#f08c1a" {S}/><circle cx="33" cy="20" r="2" fill="{INK}"/>'
         f'<path d="M14 28c4 6 12 6 16 0-6-2-12-2-16 0z" fill="#fff" opacity=".6" {S}/><path d="M20 40v5M27 40v5" {S}/>'),
 "block": ("#f08c1a", f'<rect x="7" y="7" width="34" height="34" rx="4" fill="{{C}}" {S}/><rect x="14" y="14" width="20" height="20" rx="3" fill="#fff" opacity=".85" {S}/>'),
 "cube": ("#1aa37a", f'<path d="M8 18l16-8 16 8v18l-16 8-16-8z" fill="{{C}}" {S}/><path d="M8 18l16 8 16-8M24 26v18" fill="none" {S}/>'
         f'<path d="M24 26l16-8v18l-16 8z" fill="#000" opacity=".15"/><ellipse cx="24" cy="14" rx="5" ry="2.5" fill="#fff" opacity=".7" {S}/>'),
 "book": ("#2f7fd8", f'<path d="M10 7h26a3 3 0 0 1 3 3v31H13a3 3 0 0 1-3-3z" fill="{{C}}" {S}/><path d="M10 38a3 3 0 0 1 3-3h26v6H13a3 3 0 0 1-3-3z" fill="#fff" {S}/>'
         f'<path d="M17 7v28" stroke="{INK}" stroke-width="2"/><rect x="21" y="14" width="13" height="6" rx="1.5" fill="#fff" opacity=".85"/>'),
 "box": ("#c98a4b", f'<path d="M6 18h36v24H6z" fill="{{C}}" {S}/><path d="M6 18l6-10h24l6 10" fill="#e0aa70" {S}/><path d="M24 8v34" stroke="{INK}" stroke-width="2"/>'
        '<rect x="19" y="18" width="10" height="7" fill="#f2d3a8"/>'),
 "bug": ("#e2563b", f'<circle cx="24" cy="12" r="6" fill="{INK}"/><path d="M20 8l-4-5M28 8l4-5" {S}/><ellipse cx="24" cy="28" rx="16" ry="15" fill="{{C}}" {S}/>'
        f'<path d="M24 13v30" stroke="{INK}" stroke-width="2.4"/><circle cx="16" cy="24" r="3" fill="{INK}"/><circle cx="32" cy="24" r="3" fill="{INK}"/>'
        f'<circle cx="17" cy="34" r="2.6" fill="{INK}"/><circle cx="31" cy="34" r="2.6" fill="{INK}"/>'),
 "button": ("#f27fae", f'<circle cx="24" cy="24" r="18" fill="{{C}}" {S}/><circle cx="24" cy="24" r="12" fill="none" stroke="{INK}" stroke-width="1.6" opacity=".5"/>'
           f'<circle cx="19" cy="19" r="2.6" fill="{INK}"/><circle cx="29" cy="19" r="2.6" fill="{INK}"/><circle cx="19" cy="29" r="2.6" fill="{INK}"/><circle cx="29" cy="29" r="2.6" fill="{INK}"/>'),
 "car": ("#e2563b", f'<path d="M4 32v-7c0-3 2-5 5-5h5l6-8h12l7 8h3c3 0 4 2 4 5v7z" fill="{{C}}" {S}/><path d="M17 20l4-6h9v6zM33 20v-6l5 6z" fill="#e2e6ff" {S}/>'
        f'<circle cx="14" cy="33" r="5.5" fill="{INK}"/><circle cx="35" cy="33" r="5.5" fill="{INK}"/><circle cx="14" cy="33" r="2" fill="#fff"/><circle cx="35" cy="33" r="2" fill="#fff"/>'),
 "cat": ("#f08c1a", f'<path d="M9 18l2-13 9 7h8l9-7 2 13c3 4 3 10 0 14-3 6-9 9-15 9s-12-3-15-9c-3-4-3-10 0-14z" fill="{{C}}" {S}/>'
        f'<circle cx="18" cy="24" r="2.4" fill="{INK}"/><circle cx="30" cy="24" r="2.4" fill="{INK}"/><path d="M22 29l2 2 2-2z" fill="{INK}" {S}/>'
        f'<path d="M4 28h9M4 33l9-2M44 28h-9M44 33l-9-2" stroke="{INK}" stroke-width="1.6"/>'),
 "dog": ("#c98a4b", f'<path d="M12 14c0-4 3-6 6-6h12c3 0 6 2 6 6v14c0 8-5 13-12 13S12 36 12 28z" fill="{{C}}" {S}/>'
        f'<path d="M12 12c-5 0-8 5-7 14 1 4 5 4 7 1zM36 12c5 0 8 5 7 14-1 4-5 4-7 1z" fill="#7a4a24" {S}/>'
        f'<circle cx="19" cy="21" r="2.4" fill="{INK}"/><circle cx="29" cy="21" r="2.4" fill="{INK}"/><ellipse cx="24" cy="29" rx="4" ry="3" fill="{INK}"/>'
        f'<path d="M24 32v3c-2 2-4 2-5 1M24 35c2 2 4 2 5 1" fill="none" {S}/>'),
 "cookie": ("#d9a05b", f'<circle cx="24" cy="24" r="18" fill="{{C}}" {S}/><circle cx="17" cy="18" r="2.6" fill="#5b3418"/><circle cx="29" cy="16" r="2.4" fill="#5b3418"/>'
           '<circle cx="31" cy="28" r="2.8" fill="#5b3418"/><circle cx="19" cy="31" r="2.4" fill="#5b3418"/><circle cx="25" cy="23" r="2" fill="#5b3418"/>'),
 "crayon": ("#2f7fd8", f'<path d="M5 18h28v12H5z" fill="{{C}}" {S}/><path d="M33 18l10 6-10 6z" fill="#ffe8d0" {S}/><path d="M39 21.6l4 2.4-4 2.4z" fill="{{C}}"/>'
           f'<path d="M11 18v12M27 18v12" stroke="#fff" stroke-width="2.4"/><path d="M5 18h28v12H5z" fill="none" {S}/>'),
 "cup": ("#2f7fd8", f'<path d="M9 12h26l-3 28H12z" fill="{{C}}" {S}/><path d="M34 17c8 0 9 12 0 13" fill="none" stroke="{INK}" stroke-width="3.5"/>'
        f'<path d="M9 12h26" {S}/><path d="M14 18l1 14" stroke="#fff" stroke-width="2.4" stroke-linecap="round" opacity=".7"/>'),
 "duck": ("#f5c400", f'<path d="M8 28c0-4 4-6 8-5 2-6 6-10 12-10 7 0 10 5 10 9 0 3-1 5-3 6 4 1 7 3 7 7 0 6-8 9-17 9-11 0-17-6-17-16z" fill="{{C}}" {S}/>'
         f'<path d="M37 18l8 2-7 3" fill="#f08c1a" {S}/><circle cx="32" cy="18" r="2" fill="{INK}"/><path d="M15 31c4 4 10 4 14 0" fill="none" {S}/>'),
 "egg": ("#fff4dc", f'<path d="M24 5c9 0 15 14 15 23s-7 15-15 15S9 37 9 28 15 5 24 5z" fill="{{C}}" {S}/><path d="M17 20c1-4 3-7 5-8" fill="none" stroke="#fff" stroke-width="3" stroke-linecap="round"/>'),
 "fish": ("#f08c1a", f'<path d="M6 24c6-10 20-13 30 0-10 13-24 10-30 0z" fill="{{C}}" {S}/><path d="M35 24l9-8v16z" fill="{{C}}" {S}/>'
         f'<circle cx="15" cy="22" r="2.2" fill="{INK}"/><path d="M22 18c3 3 3 9 0 12" fill="none" stroke="{INK}" stroke-width="1.8"/>'),
 "flower": ("#f27fae", f'<path d="M24 30v15" stroke="#1aa37a" stroke-width="3.5" stroke-linecap="round"/><path d="M24 40c4-5 9-5 11-3-3 4-7 5-11 3z" fill="#1aa37a" {S}/>'
           + ''.join(f'<circle cx="{24 + 9 * c:.1f}" cy="{18 + 9 * s:.1f}" r="7" fill="{{C}}" {S}/>' for c, s in ((1, 0), (.31, .95), (-.81, .59), (-.81, -.59), (.31, -.95)))
           + f'<circle cx="24" cy="18" r="5.5" fill="#f5c400" {S}/>'),
 "frog": ("#1aa37a", f'<ellipse cx="24" cy="30" rx="19" ry="13" fill="{{C}}" {S}/><circle cx="15" cy="16" r="7" fill="{{C}}" {S}/><circle cx="33" cy="16" r="7" fill="{{C}}" {S}/>'
         f'<circle cx="15" cy="16" r="3.5" fill="#fff"/><circle cx="33" cy="16" r="3.5" fill="#fff"/><circle cx="15" cy="16" r="1.8" fill="{INK}"/><circle cx="33" cy="16" r="1.8" fill="{INK}"/>'
         f'<path d="M14 31c6 5 14 5 20 0" fill="none" {S}/>'),
 "hat": ("#8a5cf0", f'<path d="M24 5L12 38h24z" fill="{{C}}" {S}/><path d="M17 24h14M20 15h8" stroke="#f5c400" stroke-width="3"/>'
        f'<circle cx="24" cy="5" r="3.5" fill="#f5c400" {S}/><path d="M8 38h32v4H8z" fill="#f5c400" {S}/>'),
 "kite": ("#e2563b", f'<path d="M22 4l14 16-14 18L8 20z" fill="{{C}}" {S}/><path d="M22 4v34M8 20h28" stroke="{INK}" stroke-width="1.8"/>'
         f'<path d="M22 4l14 16H22zM22 38L8 20h14z" fill="#fff" opacity=".4"/><path d="M22 38c2 3 6 4 8 7" fill="none" {S}/>'
         f'<path d="M26 41l2-3 2 3zM30 46l2-3 2 3z" fill="#f5c400" {S}/>'),
 "leaf": ("#1aa37a", f'<path d="M8 40C6 22 18 8 42 6c1 22-12 35-34 34z" fill="{{C}}" {S}/><path d="M8 40L32 16M18 30l-2-8M24 24l8 1" fill="none" stroke="#0c5c40" stroke-width="2" stroke-linecap="round"/>'),
 "pen": ("#2f7fd8", f'<path d="M6 21h28v8H6z" fill="{{C}}" {S}/><path d="M34 21l9 4-9 4z" fill="#e2e6ff" {S}/><path d="M6 21h11v8H6z" fill="{INK}" opacity=".35"/>'
        f'<path d="M9 21v-4h12" fill="none" stroke="{INK}" stroke-width="2.2" stroke-linecap="round"/><circle cx="42" cy="25" r="1.2" fill="{INK}"/>'),
 "pencil": ("#f5c400", f'<path d="M10 20h24v9H10z" fill="{{C}}" {S}/><path d="M4 20h6v9H4z" fill="#f27fae" {S}/><path d="M34 20l9 4.5-9 4.5z" fill="#ffe8d0" {S}/>'
           f'<path d="M40 23l3 1.5-3 1.5z" fill="{INK}"/><path d="M10 24.5h24" stroke="#fff" stroke-width="1.6" opacity=".7"/>'),
 "rock": ("#9aa0b4", f'<path d="M6 34c-2-8 4-18 13-20 6-6 15-4 19 2 6 2 8 10 5 16-2 6-9 8-18 8-10 0-17-1-19-6z" fill="{{C}}" {S}/>'
         '<path d="M16 22c3-3 7-4 10-3" fill="none" stroke="#fff" stroke-width="2.6" stroke-linecap="round" opacity=".7"/>'),
 "shell": ("#f7a98b", f'<path d="M24 42L7 22c2-10 9-16 17-16s15 6 17 16z" fill="{{C}}" {S}/><path d="M24 42L13 11M24 42L24 6M24 42l11-31M24 42L8 20M24 42l16-22" fill="none" stroke="{INK}" stroke-width="1.6"/>'
          f'<path d="M18 42h12l-6-5z" fill="{{C}}" {S}/>'),
 "star": ("#f5c400", f'<path d="M24 5l5.6 11.4 12.6 1.8-9.1 8.9 2.1 12.5L24 33.7l-11.2 5.9 2.1-12.5-9.1-8.9 12.6-1.8z" fill="{{C}}" {S}/>'
         f'<circle cx="20" cy="22" r="1.6" fill="{INK}"/><circle cx="28" cy="22" r="1.6" fill="{INK}"/><path d="M20 27c2.5 2.5 5.5 2.5 8 0" fill="none" stroke="{INK}" stroke-width="2" stroke-linecap="round"/>'),
 "straw": ("#e2563b", f'<path d="M20 44l3-36h6l-3 36z" fill="#fff" {S}/><path d="M22.3 36l.6-6h5.7l-.6 6zM23.3 24l.5-6h5.6l-.5 6zM24.2 12l.3-4h4.5l-.3 4z" fill="{{C}}"/>'
          f'<path d="M20 44l3-36h6l-3 36z" fill="none" {S}/><path d="M23 8l-4-4" {S}/>'),
 "balloon": ("#e2563b", f'<path d="M24 34c-9 0-14-8-14-15S16 5 24 5s14 7 14 14-5 15-14 15z" fill="{{C}}" {S}/><path d="M21 34h6l-3 4z" fill="{{C}}" {S}/>'
            f'<path d="M24 38c-3 3 3 5 0 9" fill="none" stroke="{INK}" stroke-width="1.8"/><path d="M17 13c1-3 3-4 5-5" fill="none" stroke="#fff" stroke-width="2.6" stroke-linecap="round" opacity=".7"/>'),
 "carrot": ("#f08c1a", f'<path d="M14 14l22 4c-5 12-14 20-28 26 2-12 3-22 6-30z" fill="{{C}}" {S}/><path d="M18 22l5 1M14 32l5 1" stroke="{INK}" stroke-width="1.8"/>'
           f'<path d="M30 16c2-6 6-9 10-10-1 5-4 8-8 10M28 15c-1-5 0-9 3-11 2 4 1 8-1 11" fill="#1aa37a" {S}/>'),
 "strawberry": ("#e2563b", f'<path d="M24 44C12 36 7 26 9 19c2-6 10-7 15-4 5-3 13-2 15 4 2 7-3 17-15 25z" fill="{{C}}" {S}/>'
               f'<path d="M15 14l4 4 5-5 5 5 4-4-4-6h-10z" fill="#1aa37a" {S}/>'
               + ''.join(f'<ellipse cx="{x}" cy="{y}" rx="1" ry="1.6" fill="#ffe08a"/>' for x, y in ((17, 24), (24, 22), (31, 24), (20, 31), (28, 31), (24, 37)))),
 "orange": ("#f08c1a", f'<circle cx="24" cy="26" r="17" fill="{{C}}" {S}/><path d="M24 9c1-3 3-4 6-4" fill="none" {S}/><path d="M25 9c4-4 9-3 11 0-4 3-8 3-11 0z" fill="#1aa37a" {S}/>'
            + ''.join(f'<circle cx="{x}" cy="{y}" r=".9" fill="#b85d00"/>' for x, y in ((17, 22), (30, 20), (33, 31), (19, 34), (25, 28)))),
 "toy": ("#1aa37a", f'<rect x="10" y="10" width="28" height="28" rx="6" fill="{{C}}" {S}/><circle cx="24" cy="24" r="7" fill="#f5c400" {S}/>'),
}
ALIASES = {"apples": "apple", "balls": "ball", "beads": "bead", "marbles": "marble", "bees": "bee", "birds": "bird", "blocks": "block",
           "cubes": "cube", "books": "book", "boxes": "box", "bugs": "bug", "ladybugs": "bug", "buttons": "button", "cars": "car",
           "cats": "cat", "dogs": "dog", "cookies": "cookie", "crayons": "crayon", "cups": "cup", "ducks": "duck", "eggs": "egg",
           "fish": "fish", "flowers": "flower", "frogs": "frog", "hats": "hat", "kites": "kite", "leaves": "leaf", "pens": "pen",
           "pencils": "pencil", "rocks": "rock", "stones": "rock", "shells": "shell", "stars": "star", "stickers": "star",
           "straws": "straw", "balloons": "balloon", "carrots": "carrot", "strawberries": "strawberry", "oranges": "orange",
           "toys": "toy", "muffins": None}
for k in list(OBJ): ALIASES.setdefault(k, k)


def lookup(noun):
    return ALIASES.get(noun.lower())


TILT = {"crayon", "pen", "pencil"}          # long, thin objects: tilt and enlarge so they fill the square


def draw(name, x, y, size=48, color=None):
    base, body = OBJ[name]
    c = TINTS.get(color, color) if color else base
    if name in TILT:
        body = f'<g transform="rotate(-38 24 24) translate(24 24) scale(1.25) translate(-24 -24)">{body}</g>'
    return f'<g class="o" data-o="{name}" transform="translate({x:.1f} {y:.1f}) scale({size / 48:.4f})">{body.replace("{C}", c)}</g>'


def cross(x, y, size=48):
    k = size / 48
    a, b = x + 6 * k, x + 42 * k
    c, d = y + 6 * k, y + 42 * k
    return (f'<path class="x" d="M{a:.1f} {c:.1f}L{b:.1f} {d:.1f}M{a:.1f} {d:.1f}L{b:.1f} {c:.1f}" stroke="#ffffff" stroke-width="{9 * k:.1f}" stroke-linecap="round"/>'
            f'<path d="M{a:.1f} {c:.1f}L{b:.1f} {d:.1f}M{a:.1f} {d:.1f}L{b:.1f} {c:.1f}" stroke="{INK}" stroke-width="{5 * k:.1f}" stroke-linecap="round"/>')


def outline(x, y, size=48):
    """Dashed empty slot: a place for an object that is not there yet."""
    k = size / 48
    return (f'<rect class="s" x="{x + 5 * k:.1f}" y="{y + 5 * k:.1f}" width="{38 * k:.1f}" height="{38 * k:.1f}" rx="{10 * k:.1f}" fill="none" '
            f'stroke="#9aa3d6" stroke-width="{2.4 * k:.1f}" stroke-dasharray="{5 * k:.1f} {4 * k:.1f}"/>')
